<div>
	<!-- Font awesome 5 -->

	<div class="landingPage ">
		@include('livewire.layouts.header')
		<!-- ================ SECTION INTRO ================ -->

		<section class="section-intro bg-dark-grey padding-y-lg" style="margin-top:70px; background-image: url('{{asset('storage/banner/' . $selected_banner->image) }}'); 
						background-size: cover; 
						background-position: center center; 
						height: 95vh; /* Set the height to 75% of the viewport height */
						padding-y: 50px;
						display: flex; /* Use flexbox to vertically center content */
						justify-content: center; /* Center content horizontally */
						align-items: center; /* Center content vertically */
					">
			<div class="container">
				<article class="my-5">
					<h1 class="display-4 text-white lilita-one-regular"> {{$selected_banner->title}} </h1>
					<p class="lead text-white col-9 col-sm-8 col-lg-6 pl-0 concert-one-regular">{{$selected_banner->description}}</p>

					<nav class="nav nav-pills">
						@foreach($banners as $banner)

						@if($selected_banner_id == $banner->id)
						@php($banner_img = $banner->image)
						<div class="nav-link dots mx-2  active alata-regular" style="cursor: pointer" aria-current="page" wire:click="updateSelectedBanner('{{ $banner->id }}')"></div>
						@else
						<div class="nav-link dots mx-2  alata-regular" style="cursor: pointer;" wire:click="updateSelectedBanner('{{ $banner->id }}')"></div>
						@endif
						@endforeach

					</nav>

					<a href="#" class="btn btn-warning text-uppercase mt-3">PEDIDO EN LINEA </a>
				</article>
			</div> <!-- container end.// -->
		</section>


		<!-- ================ SECTION contact ================ -->
		<!-- <section class="contact w-100">
			<div class="container">
				<div class="row d-flex justify-between flex-row">
					<div class="left d-flex align-items-center col-md-10 col-sm-8  ">
						<i class="fa-solid text-light fs-2 pr-2  fa-map-location-dot mainColor"></i>
						<p class="text-light fs-lg-6">Carrer de mossen jasint <br> verdaguer, 132 08330 premia del mar</p>
					</div>
					<div class="right  align-items-center d-none d-lg-flex col-md-2 col-sm-4">
						<p class="text-light fs-lg-6 ">Mira como <br> lo hacemos</p>
						<i class="fa-solid text-light pl-2 fs-2 fa-location-arrow"></i>
					</div>
				</div>
			</div>
		</section> -->
		<!-- ================ SECTION contact END.// ================ -->

	</div>

	<!-- ================ SECTION PRODUCTS ================ -->
	<section class="padding-top products ">
		<div class="container my-4 pb-4">

			<!-- removed section heading  -->

			<div class="container">
				<div class="row">
					<!-- category filter -->
					<div class="col-4 col-xs-12 float-left">
						<div class="input-group">
							<ul class="form-select text-light" style="background: transparent; border: none;">
								<p class="fw-bold text-light text-start alata-regular">Filtro</p>
								<li value="">
					
									<a wire:click="updateSelectedCategory('{{ 0 }}')" class="text-decoration-none alata-regular 
									{{ $selected_category_id == 0 ? 'selected' : '' }} 
									text-light" style="cursor:pointer">
										Featured
									</a>
									
								</li>

								@foreach($categories as $category)
								<li value="">
									<a wire:click="updateSelectedCategory('{{ $category->id }}')" class="text-decoration-none alata-regular 
									{{ $category->id == $selected_category_id ? 'selected' : '' }} 
									text-light" style="cursor:pointer">
										{{ $category->name }}
									</a>
								</li>
								@endforeach
							</ul>
						</div> <!-- filter-group end.// -->
					</div> <!-- col end.// -->

					<!-- heading -->
					<div class="col  mx-auto">
						<h3 class="section-title fw-bold text-light fs-1 pb-2 pl-1 text-left">PLATOS <br> FAVORITOS</h3>
					</div> <!-- col end.// -->
				</div> <!-- row end.// -->
			</div> <!-- container end.// -->

			<div class="row">
			
				@foreach($selected_products as $product)
				@php($discount = $product->discount)
				@php($discount_amount = $product->discount_type=='amount'? $product->discount : ($product->price * $product->discount) /100)
				@php($whishlist_product = \App\Model\Wishlist::where('user_id', auth()->user()->id)->where('product_id', $product->id)->first())
				<div class="col-lg-3 {{$hovered_product_id == $product->id? 'cardParent' : ''}}  col-md-4  col-sm-6 col-xs-12">

					<figure class="card card-product-grid">
						<a wire:click="updateHoveredProduct('{{ $product->id }}')" class="img-wrap" style="cursor:pointer">

							<img src="https://s3-alpha-sig.figma.com/img/a0c5/5d0d/ce0094a606b490197cb8771434321fa3?Expires=1710720000&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=Ok72pyJa0zB0G6PvobmKkcsCzr6SgLYCDGWxjEsZssw9dSyS1THb9RztWkrgX10KEYWCTGlv7QV-7jzGZwQdudMvyVoLCcfHCbWdQJX0dH0dMB~rAz7vQKXY49fZVd4~yTymAOL8LhfFAhg~mIgJ5Kb4vF1VSadd~58b7mMWWN58sWAcRLatSZD5HFzuYGis0OLLsSiVJ9VeBTnsYXGC1Hq8UtDiIj0vZy4Lb5X~zkyeHpUV4WpykRrLTc-n8jjDNQpRYx1Ym8EEGJRhtzgfk4r0FS4UUPIm1e3gWFoS~j2oHk2VcxBsuLiiW8tOMrNCgcHIzhS6~5IzVgCmuu877Q__">
							<!-- <img src="{{ asset('storage/product/' . $product->image) }}"> -->
						</a>

						<figcaption class="info-wrap">
							<div class="infoIcon d-flex justify-content-end">

								<a href="">
									<i class="fa-solid fa-circle-info"></i>
									<p class="w-75 InfoTip p-3 text-light">
										Tomate / mozarella / cebolla/ pimientos / calabacin / champiñones
									</p>
								</a>

							</div>
							<div class="price-wrap text-light d-flex justify-content-between">

								<span class="price text-light alata-regular">9 €</span>
								<span class="text-white-50">350gr</span>

							</div> <!-- price-wrap.// -->


							<a href="{{route('product.details', [$product->id])}}" class="title fs-5 text-truncate text-light concert-one-regular">{{$product->name}}</a>

							<p class="text-light fw-bold" style="font-size:13px">
								<span>Grande</span> /
								<span>Mediana</span> /
								<span style="color:#E74E0F">Personal</span>
							</p>

							@php($variations = json_decode($product->variations, true))

							@php($start_at_txt = '')
							@if(count($variations) > 0)
							@php($start_at_txt = 'Starts at:')
							@endif

							@foreach(json_decode($product->variations, true) as $variation)
							<!-- <small class="text-muted pr-2">{{$variation['type']}}</small> -->
							@endforeach

						</figcaption>
						<div class="card-pedir d-flex justify-content-end">
							<a href="{{route('product.details', [$product->id])}}" style="width:fit-content;"
							 class="mb-lg-4 mr-3 mb-3 mb-sm-3 text-light btn fw-bold btn-warning">
								Pedir
							</a>
						</div>

					</figure>
				</div> <!-- col end.// -->
				@endforeach
			</div> <!-- row end.// -->

			<!-- Pizza banner separator -->
			<div class="more d-flex mt-1 justify-content-center align-content-center">
				<a href="product/list" class="btn btn-warning text-center fw-bold">Ver Todos </a>
			</div>

		</div> <!-- container end.// -->

		<!-- Pizza banner -->
		<div class="pizza-banner">
			<img src="{{ asset('storage/app/public/banner/banner-2.png') }}" class="w-100" height="250px" alt="" srcset="">
		</div>
	</section>
	<!-- ================ SECTION PRODUCTS END.// ================ -->

	<!-- ================ SECTION COOKING BANNER ================ -->
	<section class="cooking">
		<div class="container">
			<!-- row 1 -->
			<div class="row align-items-center pt-5">
				<img class="col-7 col-sm-6 " src="https://s3-alpha-sig.figma.com/img/8628/b5c2/a6cb263740edcbfffe1b6f748885d5fc?Expires=1710720000&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=PzbMcjgYkoHbgVrG-03ZaS9cEglbeD66UuJu-aMYVuihWz7mgSlUdaGQWIQxTUFZuFu8D29fu9~tgc9712OFCRJWtJ6HGFTna9MQBYSX0gzplYtpB3jOLYdLrUNmyuxSK-MvSnYdbOTPuD581WSVOxRDduHZ2ZHh2riokFBdMGgte78WquloCuAxoBQGvssX9-SemJH3O2GFQShr3PVqMjMoM-rH0XA~hnYJQGX26n~OXC31WbumOHJoojo7i~Q04HDoGZttN5pDWu3oXtMci0Fb33EraVYpzxiZJOOgtV8aoZdN1AujSb3uY-5TJJoOPAD4VwXpzlqqn2lgivFJUw__" alt="" srcset="">
				<p class="fs-1 como col-4 col-sm-4  text-white ml-sm-4 px-0 fw-bold">¿Como lo <br> hacemos?</p>
			</div>
			<!-- row 2 -->
			<div class="row row2 align-items-center pt-sm-0 pt-5">
				<div class="col-md-6 col-sm-12 order-last order-sm-start padding-top-sm-0 padding-top-3 d-flex justify-content-center justify-content-sm-start mb-3 mb-md-0">
					<a class="btn Conocenos btn-warning fw-bold" href="#">Conocenos</a>
				</div>
				<div class="col-md-6 order-sm-last col-sm-12">
					<p class=" col-sm-10 mx-auto mx-sm-0 px-sm-0 text-left text-white">
						Bienvenido a <strong>La Crostini</strong>, donde la tradición
						se une con la pasión por la comida artesanal.
						Deléitate con nuestras irresistibles pizzas,
						pastas al dente y hamburguesas gourmet,
						elaboradas con ingredientes cuidadosamente
						seleccionados.
					</p>
				</div>
			</div>

			<!-- row 3 -->
			<div class="joint w-100 d-flex justify-content-center">
				<a class="btn btn-warning col-10 col-sm-5  fs-sm-5 fs-6 fw-bold text-center text-white mx-auto" href="">TRABAJA CON NOSOTROS</a>
			</div>
		</div>
		<!-- map banner -->
		<div class="map-banner">
			<img src="{{ asset('storage/app/public/banner/bottom-banner.jpg') }}" class="w-100" alt="" srcset="">
		</div>
	</section>
	<!-- ================ SECTION COOKING BANNER END.// ================ -->


	<!-- ================ IMPORTING FOOTER COMPONENT ================ -->
	@include('livewire.layouts.footer')



	<!-- ================ CUSTOM STYLES ================ -->
	<style>
		/* styling main landing page */
		.landingPage {
			background: #151515 no-repeat center/cover;
			background-blend-mode: multiply;
			min-height: 95vh;
		}

		section.contact {
			position: absolute;
			top: 106vh;
		}

		.mainColor {
			color: #E74E0F !important;
		}

		.landingPage>div {
			background: linear-gradient(to bottom, #000000 90%, transparent);
		}


		section.sliding {
			margin-top: 70px !important;
		}

		.landingPage .section-intro .card-banner,
		.landingPage .section-intro .card {
			background: none !important;
			border: none;
		}

		.landingPage .section-intro .card {
			margin-top: 130px;

		}

		.bottom-sticker {
			position: absolute;
			bottom: 0;
			left: 0;
			width: 100%;
			background-color: rgba(0, 0, 0, 0.7);
			color: #fff;
			padding: 5px;
			text-align: center;
		}
		.title,
		.price {
			display: block;
			font-size: 14px;
		}

		.price {
			font-weight: bold;
		}

		.dots {
			width: 10px !important;
			height: 10px !important;
			border-radius: 50% !important;
			padding: 0 !important;
			background: white !important;
		}

		.nav-pills .nav-link.active,
		.nav-pills .show>.nav-link {
			background: #E74E0F !important;
		}

		a.btn-warning {
			color: white !important;
			background-color: #e74e0f !important;
			border-color: #e74e0f !important;

		}

		a.btn-warning:focus {
			box-shadow: none;
		}

		/* styling products section*/
		section.products {
			background: url("https://s3-alpha-sig.figma.com/img/3724/c57c/6133a80bd954d2c808bf20577662db14?Expires=1710720000&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=lXEin1Ef~08opv9FLO1w9Kttg470poX2~2Hbf~Z88Osw98Xxwn0AxEdlotFVDnxoEPTd5fZwWjSxmbQtXfCyi7sVKL0-VrlKexbPJP7Qi7fjHPaiakBKQFBDkljmYEpXfOhtC3mUTKhBo~wUlMpqJhLZUxyve-cmCtkxo1jMr6rm-ruekJ9uZHFFDdC1~L94fsEuJGIHxGa1i9c~SI-jXM0ywgLe9HpE7Nd9HUG2Dy5aoeEuYeJAwQK3QHlEHjc-jw8lVKf46NSLaeY-0P5bCj2D7-U7qT~CGEV8nuVZgA41m0IrUXsL1JkaTNgSCUcbi4s9E2pDO-zyed0H9msI1A__") no-repeat center/cover;
			min-height: 100%;
		}

		.products .section-title {
			position: relative;
			font-family: Gotham Black, sans-serif;
			width: fit-content;
		}

		.infoIcon a i {
			color: #E74E0F;
			position: relative;
		}

		.infoIcon a:hover .InfoTip {
			display: block !important;
		}

		.InfoTip {
			display: none !important;
			position: absolute;
			background: #ffffffd9;
			color: black !important;
			font-size: 10px;
			bottom: 43%;
			right: 5%;
			border-radius: 5px;
			display: block;
			z-index: 99999 !important;
		}

		.InfoTip::before {
			content: "";
			position: absolute;
			width: 15px;
			height: 10px;
			background: #ffffffd9;
			clip-path: polygon(50% 100%, 0 0, 100% 0);
			top: 100%;
			right: 8px;
		}

		.products .section-title::before {
			content: "";
			position: absolute;
			width: 100%;
			height: 6px;
			background-color: #E74E0F;
			bottom: 0;
			left: 0;
		}

		.products .card {
			background: #292929;
			border-radius: 20px !important;
		}

		.products .cardParent .card {
			background: #E74E0F;
		}

		.products .cardParent figcaption .infoIcon a i {
			color: white !important;
		}

		.products .cardParent .card a.btn-warning {
			background: #292929 !important;
			border-color: #292929 !important;
		}

		.products .cardParent .card p span:last-child {
			color: #292929 !important;
		}

		li::marker {
			color: #E74E0F;
		}

		.input-group {
			display: flex;
			justify-content: flex-start;
		}

		.section-title {
			margin-top: 30px;
		}

		a.selected {
			position: relative;
			color: #E74E0F !important;
		}

		.selected::before {
			content: "";
			position: absolute;
			width: 100%;
			height: 2px;
			background-color: #E74E0F;
			bottom: 0;
			left: 0;
		}

		/* styling Cooking section*/
		section.cooking {
			background: url("https://s3-alpha-sig.figma.com/img/3724/c57c/6133a80bd954d2c808bf20577662db14?Expires=1710720000&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=lXEin1Ef~08opv9FLO1w9Kttg470poX2~2Hbf~Z88Osw98Xxwn0AxEdlotFVDnxoEPTd5fZwWjSxmbQtXfCyi7sVKL0-VrlKexbPJP7Qi7fjHPaiakBKQFBDkljmYEpXfOhtC3mUTKhBo~wUlMpqJhLZUxyve-cmCtkxo1jMr6rm-ruekJ9uZHFFDdC1~L94fsEuJGIHxGa1i9c~SI-jXM0ywgLe9HpE7Nd9HUG2Dy5aoeEuYeJAwQK3QHlEHjc-jw8lVKf46NSLaeY-0P5bCj2D7-U7qT~CGEV8nuVZgA41m0IrUXsL1JkaTNgSCUcbi4s9E2pDO-zyed0H9msI1A__") no-repeat center/cover;

		}

		.como {
			width: fit-content;
			padding-bottom: 10px;
		}

		.como::before {
			content: "";
			position: absolute;
			width: 85%;
			height: 9px;
			background-color: #E74E0F;
			bottom: 0;
			left: 0;
		}

		.Conocenos.btn-warning {
			width: 130px !important;
			border-radius: 0 !important;
		}

		.cooking .container .row2 {
			margin-bottom: 6rem !important;

		}

		.col-9.text-left.text-white {
			font-size: 13px;
		}

		/* row 3 styling */
		.cooking .container {
			position: relative;
			min-height: 100%
		}

		.joint {
			position: absolute;
			bottom: -115px;
		}

		.joint .btn-warning {
			border-radius: 0 !important;
			margin-top: 10px
		}
	</style>
</div>