
<div>
@include('livewire.layouts.header')

<!-- ============== SECTION PAGETOP ============== -->
<section class="bg-primary padding-y-sm">
        <div class="container">
        <small style="color:white; cursor:pointer"> Home</small> 
        <i style="color:white" class="dot"></i>
          @foreach($categories as $category)
          <small style="color:white; cursor:pointer"> {{$category->name}}</small> 
          <i style="color:white" class="dot"></i>
          @endforeach
        
      
        </div> <!-- container //  -->
    </section>
<!-- ============== SECTION PAGETOP END// ============== -->

<!-- ============== SECTION CONTENT ============== -->

<!-- =================== COMPONENT 3 ======================= -->
<section class="padding-y bg-white shadow-sm">
<div class="container">

<div class="row">
<aside class="col-lg-5">
	<article class="gallery-wrap"> 

		<a href="#" class="img-big-wrap"><img src="../images/items/detail3/big.jpg" class="rounded"></a>
		
		<div class="thumbs-wrap">
		  <a href="#" class="item-thumb"> <img src="../images/items/detail3/thumb1.jpg"> </a>
		  <a href="#" class="item-thumb"> <img src="../images/items/detail3/thumb2.jpg"> </a>
		  <a href="#" class="item-thumb"> <img src="../images/items/detail3/thumb3.jpg"> </a>
		  <a href="#" class="item-thumb"> <img src="../images/items/detail3/thumb4.jpg"> </a>
		  <a href="#" class="item-thumb"> <img src="../images/items/detail3/thumb2.jpg"> </a>
		</div> <!-- thumbs-wrap.// -->
	</article> <!-- gallery-wrap .end// -->
</aside>
<main class="col-lg-4">
	<article>
		<p class="title mb-1"> {{$product->name}} </p>
		<div class="rating-wrap mb-2">
			<ul class="rating-stars">
				<li style="width:80%" class="stars-active"> <img src="../images/misc/stars-active.svg" alt=""> </li>
				<li> <img height="520" src="../images/misc/starts-disable.svg" alt=""> </li>
			</ul>
      @if(count($product->rating) >0)
			<b class="label-rating text-warning">{{ number_format($product->rating[0]['average'], 1) }}</b>
      @else
      <b class="label-rating text-muted">0</b>
      @endif
			<i class="dot"></i>
			<span class="label-rating text-muted"> <i class="fa fa-comment"></i>  {{\App\Model\OrderDetail::where('product_id', $product->id)->count()}}  </span>
			<i class="dot"></i>
			<span class="label-rating text-muted"> <i class="fa fa-shopping-basket"></i> 154 orders </span>
		</div> <!-- rating-wrap.// -->
		<!-- <p class="text-success"> <i class="fa fa-check"></i> in Stock </p> -->
		<hr>
    @foreach($choice_options as $key_1 => $choice_option) 
		<div class="mb-4">
			<div class="text-muted mb-2">{{$choice_option['title']}}</div>
			<div>
      @foreach($choice_option['options'] as $key_2 => $option)
    <label class="checkbox-btn">
        <input type="radio" wire:model="selected_option_new.{{ $key_1 . '_' . $key_2 }}"> <span class="btn btn-light">{{ $option }}</span>
    </label>
@endforeach
			</div>
		</div>
    @endforeach
	
		<ul class="list-dots mb-4">
			<li> Materials: Leather  </li>
			<li> Size: 23 inch x 31 inch </li>
			<li> Weight: 1200 gramm </li>
			<li> Color: Brown </li>
		</ul>

	</article> <!-- product-info-aside .// -->
</main> <!-- col.// -->
<aside class="col-lg-3">

<div class="card shadow-sm">
	<div class="card-body">
		<div class="mb-3"> 
			<var class="price h5">$815.00</var> 
			<span class="text-muted">/per kg</span> 
		</div> 

		<form>
			<div class="d-flex align-items-center mb-3">
				
				<div class="input-group" style="max-width:140px">
	              <button class="btn btn-icon btn-light" type="button"> 
	                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="#999" viewBox="0 0 24 24">
	                    <path d="M19 13H5v-2h14v2z"/>
	                  </svg>
	              </button>
	              <input class="form-control text-center" readonly placeholder="" value="14">
	              <button class="btn btn-icon btn-light" type="button"> 
	                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="#999" viewBox="0 0 24 24">
	                    <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>
	                  </svg>
	              </button>
	            </div> <!-- input-group.// --> 

				<span class="p-2"> Kg </span>
			</div>
		</form>
		
		<div class="mb-4">
			<a href="#" class="btn btn-primary w-100 mb-2">Add to cart</a>
			<a href="#" class="btn btn-warning w-100 mb-2">Buy now</a>
			<a href="#" class="btn btn-light w-100"> Add to wishlist </a>
		</div>

		<ul class="list-icon">
			<li> <i class="icon fa fa-truck"></i> Worldwide shipping </li>
			<li> <i class="icon fa fa-lock"></i> Secure payment </li>
			<li> <i class="icon fa fa-star"></i> 2 Years full waranty </li>
		</ul>
	</div> <!-- card-end.// -->
</div> <!-- card.// -->

</aside>
</div> <!-- row.// -->

</div> <!-- container .//  -->
</section>
<!-- ====================== COMPONENT 3 END .// ===================== -->
<!-- ============== SECTION CONTENT END// ============== -->

<!-- ============== SECTION  ============== -->
<section class="padding-y bg-light border-top">
<div class="container">
<div class="row">
  <div class="col-lg-8">
<!-- =================== COMPONENT SPECS ====================== -->

<!-- =================== COMPONENT SPECS .// ================== -->   
  </div> <!-- col.// -->
  <aside class="col-lg-4">
<!-- =================== COMPONENT ADDINGS ====================== -->
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Similar items</h5>
         
        @foreach($similar_products as $similar_product)
        @php($discount = $similar_product->discount)
	      @php($discount_amount = $similar_product->discount_type=='amount'? $similar_product->discount : ($similar_product->price * $similar_product->discount) /100)
        <article class="itemside mb-3">
          <a href="{{route('product.details', [$similar_product->id])}}" class="aside">
            <img src="{{ asset('storage/app/public/product/' . $similar_product->image) }}" width="96" height="96" class="img-md img-thumbnail">
          </a>
          <div class="info">
            <a href="{{route('product.details', [$similar_product->id])}}" class="title mb-1"> {{$similar_product->name}} </a>

            @php($start_at_txt = '')
            @if(json_decode($similar_product->variations > 0))
            @php($start_at_txt = 'Starts at:')
            @endif
            
            <strong class="price">{{$start_at_txt}} ${{$similar_product->price}}</strong> <!-- price.// -->
            @if($similar_product->discount > 0)
						<del class="price-old">€{{$similar_product->price - $discount_amount}}</del>
						@endif
          </div>
        </article>
        @endforeach


      </div> <!-- card-body .// -->
    </div> <!-- card .// -->
<!-- =================== COMPONENT ADDINGS .// ================== --> 
  </aside> <!-- col.// -->
</div>

<br><br>

</div><!-- container // -->
</section>
<!-- =============== SECTION  END// ============== -->

@include('livewire.layouts.footer')

</div>