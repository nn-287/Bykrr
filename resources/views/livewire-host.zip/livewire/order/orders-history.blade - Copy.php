<div>

@include('livewire.layouts.header')

<section class="padding-y bg-light">
<div class="container">

<!-- =========================  COMPONENT ACCOUNT 1 ========================= --> 
<div class="row">
	<aside class="col-lg-3">
		<!--  COMPONENT MENU LIST  -->
		<div class="card p-3 h-100">
		   <nav class="nav flex-column nav-pills">
		      <a class="nav-link active" href="#">Account main</a>
		      <a class="nav-link" href="#">New orders</a>
		      <a class="nav-link" href="#">Orders history</a>
		      <a class="nav-link" href="#">My wishlist</a>
		      <a class="nav-link" href="#">Transactions</a>
		      <a class="nav-link" href="#">Profile setting</a>
		      <a class="nav-link" href="#">Log out</a>
		    </nav>
		</div>
		<!--   COMPONENT MENU LIST END .//   -->
	</aside>
	<main class="col-lg-9">
		<article class="card">
		<div class="card-body">

			<figure class="itemside align-items-center">
				<div class="aside">
					<img src="../images/avatars/avatar.jpg" class="icon-md img-avatar">
				</div>
				<figcaption class="info">
					<h6 class="title">Mr. Jackson Mike</h6>
					<p>Email: myusername@gmail.com <i class="dot"></i> Phone: +1234567890988 
						<a href="#" class="px-2"><i class="fa fa-pen"></i></a>
					</p>
				</figcaption>
			</figure>
			<hr>
			<p class="text-muted">Delivery addresses</p>
			<div class="row g-2 mb-3"> 
				<div class="col-md-6">
					<article class="box">
						<b class="mx-2 text-muted"><i class="fa fa-map-marker-alt"></i></b> 
						Tashkent city, Street name, Building 123, House 321
					</article>
				</div> <!-- col.// -->
				<div class="col-md-6">
					<article class="box">
						<b class="mx-2 text-muted"><i class="fa fa-map-marker-alt"></i></b> 
						 Moscow city, Street name, Building lenin, House 77
					</article>
				</div> <!-- col.// -->
			</div> <!-- row.// -->

			<a href="#" class="btn btn-outline-primary"> <i class="me-2 fa fa-plus"></i> Add new address </a>

			<hr>

			<p  class="text-muted">Payment methods</p>

			<div class="row g-2 mb-3"> 
				<div class="col-md-6">
					<article class="box">
						<b class="mx-2 text-muted"><i class="fa fa-credit-card"></i></b> 
						Visaâ€†â€¢â€¢â€¢â€¢â€†9905, Exp: 12/21
					</article>
				</div> <!-- col.// -->
			</div> <!-- row.// -->

			<a href="#" class="btn btn-outline-primary"> <i class="me-2 fa fa-plus"></i> Add payment method </a>

		</div> <!-- card-body .// -->
		</article> <!-- card .// --> 
	</main>
</div> <!-- row.// -->
<!-- =========================  COMPONENT ACCOUNT 1 END.// ========================= --> 


<br> <br>


<!-- =========================  COMPONENT ACCOUNT 2 ========================= --> 
<div class="row">
	<aside class="col-lg-3">
		<!--  COMPONENT MENU LIST  -->
		<div class="card p-3 h-100">
		   <nav class="nav flex-column nav-pills">
		      <a class="nav-link" href="#">Account main</a>
		      <a class="nav-link active" href="#">New orders</a>
		      <a class="nav-link" href="#">Orders history</a>
		      <a class="nav-link" href="#">My wishlist</a>
		      <a class="nav-link" href="#">Transactions</a>
		      <a class="nav-link" href="#">Profile setting</a>
		      <a class="nav-link" href="#">Log out</a>
		    </nav>
		</div>
		<!--   COMPONENT MENU LIST END .//   -->
	</aside>
	<main class="col-lg-9">
		
		<article class="card mb-3">
		<div class="card-body">
			<header class="d-md-flex">
				<div class="flex-grow-1">
					<h6 class="mb-0"> 
						Order ID: 1032 <i class="dot"></i><span class="text-danger"> Pending </span>
					</h6>
					<span>Date: 16 December 2020</span>
				</div>
				<div>
					<a href="#" class="btn btn-sm btn-outline-danger">Cancel order</a>
					<a href="#" class="btn btn-sm btn-primary">Track order</a> 
				</div>
			</header>
			<hr>
			<div class="row">
				<div class="col-md-4">
					<p class="mb-0 text-muted">Contact</p>
					<p class="m-0"> 
						Alex Donald <br>  Phone: 109-295-9131 <br> Email: info@mywebsite.com </p>
				</div> <!-- col.// -->
				<div class="col-md-4 border-start">
					<p class="mb-0 text-muted">Shipping address</p>
					<p class="m-0"> United States <br> 
						600 Markley Street, Suite 170777 Port Reading, NJ 07064  </p>
				</div> <!-- col.// -->
				<div class="col-md-4 border-start">
					<p class="mb-0 text-muted">Payment</p>
					<p class="m-0">
						<span class="text-success"> Visa  **** 0932   </span> <br> 
						Shipping fee:  $12 <br> 
					 	Total paid:  $150.90 
					</p>
				</div> <!-- col.// -->
			</div> <!-- row.// -->
			<hr>
			<ul class="row">
				<li class="col-lg-4 col-md-6">
					<figure class="itemside mb-3">
						<div class="aside">
							<img width="72" height="72" src="../images/items/6.jpg" class="img-sm rounded border">
						</div>
						<figcaption class="info">
							<p class="title">Apple SmartWatch Series 4 Space Gray</p>
							<strong> 2x = $137.00 </strong>
						</figcaption>
					</figure> 
				</li>
				<li class="col-lg-4 col-md-6">
					<figure class="itemside mb-3">
						<div class="aside">
							<img width="72" height="72" src="../images/items/7.jpg" class="img-sm rounded border">
						</div>
						<figcaption class="info">
							<p class="title">Gaming Headset with mic</p>
							<strong> 2x = $339.90 </strong>
						</figcaption>
					</figure>
				</li>
				<li class="col-lg-4 col-md-6"> 
					<figure class="itemside mb-3">
						<div class="aside">
							<img width="72" height="72" src="../images/items/8.jpg" class="img-sm rounded border">
						</div>
						<figcaption class="info">
							<p class="title">Backpack for hiking</p>
							<strong> 2x = $339.90 </strong>
						</figcaption>
					</figure>
				</li>
			</ul>
		</div> <!-- card-body .// -->
		</article> <!-- card .// --> 

		<article class="card">
		<div class="card-body">
			<header class="d-md-flex">
				<div class="flex-grow-1">
					<h6 class="mb-0">
						Order ID: 9088  <i class="dot"></i> <span class="text-success"> Shipped </span>
					</h6>
					<span>Date: 12 January 2021</span> 
				</div>
				<div>
					<a href="#" class="btn btn-sm btn-outline-danger">Cancel order</a>
					<a href="#" class="btn btn-sm btn-primary">Track order</a> 
				</div>
			</header>
			<hr>
			<div class="row">
				<div class="col-md-4">
					<p class="mb-0 text-muted">Contact</p>
					<p class="m-0"> 
						Mike Johnatan <br>  Phone: 371-295-9131 <br> Email: info@mywebsite.com </p>
				</div> <!-- col.// -->
				<div class="col-md-4 border-start">
					<p class="mb-0 text-muted">Shipping address</p>
					<p class="m-0"> United States <br> 
						3601 Old Capitol Trail Unit A-7, Suite 170777 Wilmington, DE 19808  </p>
				</div> <!-- col.// -->
				<div class="col-md-4 border-start">
					<p class="mb-0 text-muted">Payment</p>
					<p class="m-0">
						<span class="text-success"> Visa  **** 4216   </span> <br> 
						Shipping fee:  $56 <br> 
					 	Total paid:  $456 
					</p>
				</div> <!-- col.// -->
			</div> <!-- row.// -->
			<hr>
			<ul class="row">
				<li class="col-lg-4 col-md-6">
					<figure class="itemside mb-3">
						<div class="aside">
							<img width="72" height="72" src="../images/items/9.jpg" class="img-sm rounded border">
						</div>
						<figcaption class="info">
							<p class="title">Jeans shorts for men - XL</p>
							<strong> 2x = $339.90 </strong>
						</figcaption>
					</figure> 
				</li>
				<li class="col-lg-4 col-md-6">
					<figure class="itemside mb-3">
						<div class="aside">
							<img width="72" height="72" src="../images/items/12.jpg" class="img-sm rounded border">
						</div>
						<figcaption class="info">
							<p class="title"> T-shirts blue colors - SM </p>
							<strong> 2x = $53.00 </strong>
						</figcaption>
					</figure>
				</li>
			</ul>
		</div> <!-- card-body .// -->
		</article> <!-- card .// --> 

	</main>
</div> <!-- row.// -->
<!-- =========================  COMPONENT ACCOUNT 2 END.// ========================= --> 


<br> <br>

<!-- =========================  COMPONENT ACCOUNT 3 ========================= --> 
<div class="row">
	<aside class="col-lg-3">
		<!--  COMPONENT MENU LIST  -->
		<div class="card p-3 h-100">
		   <nav class="nav flex-column nav-pills">
		      <a class="nav-link" href="#">Account main</a>
		      <a class="nav-link" href="#">New orders</a>
		      <a class="nav-link" href="#">Orders history</a>
		      <a class="nav-link" href="#">My wishlist</a>
		      <a class="nav-link" href="#">Transactions</a>
		      <a class="nav-link active" href="#">Profile setting</a>
		      <a class="nav-link" href="#">Log out</a>
		    </nav>
		</div>
		<!--   COMPONENT MENU LIST END .//   -->
	</aside>
	<main class="col-lg-9">
		<article class="card">
		<div class="card-body">

			<form>
              <div class="row">
                <div class="col-lg-8">
                  <div class="row gx-3">
                    <div class="col-6 mb-3">
                      <label class="form-label">First name</label>
                      <input class="form-control" type="text"  placeholder="Type here">
                    </div> <!-- col .// -->
                    <div class="col-6  mb-3">
                      <label class="form-label">Last name</label>
                      <input class="form-control" type="text"  placeholder="Type here">
                    </div> <!-- col .// -->
                    <div class="col-lg-6 col-md-6 mb-3">
                      <label class="form-label">Email</label>
                      <input class="form-control" type="email"  placeholder="example@mail.com">
                    </div> <!-- col .// -->
                    <div class="col-lg-6 col-md-6 mb-3">
                      <label class="form-label">Phone</label>
                      <input class="form-control" type="tel" placeholder="+1234567890">
                    </div> <!-- col .// -->
                    <div class="col-lg-12  mb-3">
                      <label class="form-label">Address</label>
                      <input class="form-control" type="text"  placeholder="Type here">
                    </div> <!-- col .// -->
                    <div class="col-lg-6 col-6 mb-3">
                      <label class="form-label">Birthday</label>
                      <input class="form-control" type="date">
                    </div> <!-- col .// -->
                  </div> <!-- row.// -->
                </div> <!-- col.// -->
                <aside class="col-lg-4">
                  <figure class="text-lg-center mt-3">
                    <img class="img-lg mb-3 img-avatar" src="../images/avatars/avatar1.jpg" alt="User Photo">
                    <figcaption>
                      <a class="btn  btn-sm btn-light" href="#">
                        <i class="fa fa-camera"></i> Upload
                      </a>
                      <a class="btn  btn-sm btn-outline-danger" href="#">
                        <i class="fa fa-trash"></i>
                      </a>
                    </figcaption>
                  </figure>
                </aside> <!-- col.// -->
              </div> <!-- row.// -->
              <br>
              <button class="btn btn-primary" type="submit">Save changes</button>
            </form>

            <hr class="my-4">

            <div class="row" style="max-width:920px">
              <div class="col-md">
                <article class="box mb-3 bg-light">
                  <a class="btn float-end btn-light btn-sm" href="#">Change</a>
                  <p class="title mb-0">Password</p>
                  <small class="text-muted d-block" style="width:70%">You can reset or change your password by clicking here</small>
                </article>
              </div> <!-- col.// -->
              <div class="col-md">
                <article class="box mb-3 bg-light">
                  <a class="btn float-end btn-outline-danger btn-sm" href="#">Deactivate</a>
                  <p class="title mb-0">Remove account</p>
                  <small class="text-muted d-block" style="width:70%">Once you delete your account, there is no going back.</small>
                </article>
              </div> <!-- col.// -->
            </div> <!-- row.// -->


		</div> <!-- card-body .// -->
		</article> <!-- card .// --> 
	</main>
</div> <!-- row.// -->
<!-- =========================  COMPONENT ACCOUNT 3 END.// ========================= --> 


<br> <br>

</div> <!-- container .//  -->
</section>

@include('livewire.layouts.footer')


</div>